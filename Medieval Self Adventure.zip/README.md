# RPG
Os códigos relacionados ao projeto final um Adventure Game com elementos de RPG.
Os módulos do Python utilizados foram:
random
json
os
colorama
time
Os módulos feitos por mim são:
personagem
historia
escolha
combates
salvamento
Esses modulos são chamados no arquivo chamado principal.