# RPG
Os códigos relacionados ao projeto final um Adventure Game com elementos de RPG.
Os módulos utilizados foram:
random
json
os
colorama
Os módulos feitos por mim são:
personagem
historia
escolha
combates
salvamento
Esses modulos são chamados no arquivo chamado principal.